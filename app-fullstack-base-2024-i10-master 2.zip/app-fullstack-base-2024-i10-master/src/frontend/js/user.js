class Usuario {
    constructor(userName, password) {
        this.userName = userName;
        this.password = password;
    }
    toString() {
        return "Username " + this.userName;
    }
}
