class Device{
  public id: number;
  public name: string;
  public description: string;
  public state: boolean;
  public type: number;
  public intensity: number;
}