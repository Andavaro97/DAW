# List of project contribuitors

* **[Agustin Bassi](https://github.com/agustinBassi)**
* **[Ernesto Giggliotti](https://github.com/ernesto-g)**
* **[Brian Ducca](https://github.com/brianducca)**
